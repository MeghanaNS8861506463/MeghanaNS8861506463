function myFun(){
    document.getElementById("hello")
    .innerHTML = 'Paragraph Changed'
}

