// document.cookie = "firstName=SpongeBob; expires=Thu, 18 Dec 2030 12:00:00 UTC; path=/"
//     console.log(document.cookie); //firstName=SpongBob

    // var cookievalue;
    // function WriteCookie(){
    //     cookievalue = 'customer_name';
    //     document.cookie = "name="+cookievalue;
    //     document.write('setting cookies:' + "name=" +cookievalue);
    // }

    // WriteCookie();


    // store the cookies//
    // document.cookie = "fName=Tom, lName=Jerry" ;

    // var cookieList =  document.cookie;
    // var cookieArray = cookieList.split(';');

    // console.log(cookieArray);
   

    // local storage

    // localStorage.setItem('class',JSON.stringify({
    //     a:10, b:'Edureka!'
    // }))
   
    // console.log(localStorage.getItem('class'));

    // localStorage.clear();


    //  sessionStorage.setItem('class',JSON.stringify({
    //     a:10, b:'Edureka!'
    //  }))

      console.log(sessionStorage.getItem('class'));


      sessionStorage.clear();

      console.log(this == window);
        console.log(this == self);
        console.log(this == frames);
        console.log(this == this);
        console.log(this == globalThis);
        console.log(this == top); 
        console.log(this == parent);