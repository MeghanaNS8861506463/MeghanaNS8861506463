// console.log("hello,Dear Priya");
               
user = {
    "name":"Tom&Jerry",
    "age":"23"
 }
//options to be given as parameter
//in fetch for making requests
//other then GET
                let options = {
                    method : 'POST',
                    header:{
                        'Content-Type': 'application/json;charset=utf-8'
                    },
                    body : JSON.stringify(user)
                }

                //Fake api for making post requests
                // API for get requests
                let fetchRes = fetch(
                    "https://dummy.restapiexample.com/api/v1/create",options);
                         //Fetchers is the promise to resolve
                
                         //it using .then() method
                         fetchRes.then(res => res.json()).then(d => {
                            console.log(d)
                         })
                
                

                
