function isEven(number){
    return number % 2 ===0 ;
}

//check if the number is odd
function isOdd(number){
    return number % 2 !==0;
}

//test

console.log(isEven(5));   //false
console.log(isEven(4));     //trye
console.log(isOdd(5));  //true
console.log(isOdd(8));   //false