import { sub, sum } from "./operations.mjs";


 const addition =sum(30,40);

const subtraction = sub(12,6);

console.log(addition);

console.log(subtraction);


